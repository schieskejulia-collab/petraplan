# External Northwind Mass Proof – Diagnose

## Ergebnis

- Quellaufträge: **830**
- Source-Schema akzeptiert: **830/830**
- Bridge-Contract-Schema bestanden: **0**
- Bridge-Contract-Schema fehlgeschlagen: **830**
- Source-Mutationen: **0**

## Warum scheitert contract.schema bei 830/830?

Der Northwind-Adapter erfindet keine fehlende Fachbedeutung. Für **STATUS** gibt es in den geprüften Northwind-Daten keinen bestätigten Gegenpart zur Bridge-Value-Map. STATUS bleibt deshalb leer. Das bestätigte Zielmodell **order-v1** verlangt für STATUS jedoch einen nichtleeren, formatgültigen Wert. Dadurch ist das Source-Schema lesbar, während das Ziel-Contract-Schema noch nicht vollständig erfüllt ist.

Bei Aufträgen mit mehreren Order_Detail-Zeilen kommt **MENGE** hinzu: Die Bridge summiert Positionsmengen nicht eigenmächtig zu einer Auftragsmenge. Ohne bestätigte Aggregationsregel bleibt MENGE leer.

## Aufteilung

- Nur STATUS fachlich unaufgelöst: **137** Fälle
- STATUS und MENGE fachlich unaufgelöst: **693** Fälle
- Andere Schema-Ursachen: **0** Fälle

Schemafehler nach Feld: **STATUS: 830** · **MENGE: 693**

## Interpretation

Die 830 Fehler in **contract.schema** bedeuten nicht, dass die fremden Northwind-Daten strukturell unlesbar waren. Das Source-Schema-Gate hat die Datensätze separat geprüft. Der Zielvertrag scheitert dort, wo ein benötigter Bridge-Wert fachlich nicht bestätigt ist.

Das ist ein wichtiger Unterschied:

1. **Source Schema Gate** – Kann die fremde Struktur sicher gelesen werden?
2. **Bridge Contract Schema** – Ist der adaptierte Datensatz für order-v1 vollständig?
3. **Semantik** – Ist die Bedeutung der Werte bestätigt?
4. **Release** – Sind alle unabhängigen Blocker gelöst?

## Entscheidung

**order-v1 wird nicht abgeschwächt. STATUS wird nicht erfunden. Mehrere Positionsmengen werden nicht ohne bestätigte Regel summiert.** Die vier Ebenen bleiben getrennt sichtbar.
